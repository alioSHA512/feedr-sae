from django.utils import unittest


class SimpleTestCase(unittest.TestCase):
    def setUp(self):
        pass

    def test_example(self):
        """Some test example"""
        pass
